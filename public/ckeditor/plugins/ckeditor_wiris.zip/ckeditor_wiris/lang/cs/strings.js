var strings = new Array();
strings['cancel'] = 'Storno';
strings['accept'] = 'OK';
strings['manual'] = 'Příručka';
strings['latex'] = 'LaTeX';