var strings = new Array();
strings['cancel'] = 'Annulla';
strings['accept'] = 'Accetta';
strings['manual'] = 'Manuale';
strings['latex'] = 'LaTeX';